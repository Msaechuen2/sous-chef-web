// import React, { useState } from 'react';
// import axios from 'axios';

// const ChatAssistant = () => {
//   const [userInput, setUserInput] = useState('');
//   const [messages, setMessages] = useState([]);

//   const handleInputChange = (e) => setUserInput(e.target.value);

//   const handleSendMessage = async () => {
//     const userMessage = { role: 'user', content: userInput };
//     setMessages([...messages, userMessage]);

//     try {
//       const response = await axios.post('/api/chat', { message: userInput });
//       const assistantMessage = { role: 'assistant', content: response.data.reply };
//       setMessages([...messages, userMessage, assistantMessage]);
//     } catch (error) {
//       console.error('Error sending message:', error);
//     }

//     setUserInput('');
//   };

//   return (
//     <div>
//       <div className="chat-window">
//         {messages.map((msg, index) => (
//           <div key={index} className={`message ${msg.role}`}>
//             {msg.content}
//           </div>
//         ))}
//       </div>
//       <input
//         type="text"
//         value={userInput}
//         onChange={handleInputChange}
//         placeholder="Ask me anything..."
//       />
//       <button onClick={handleSendMessage}>Send</button>
//     </div>
//   );
// };

// export default ChatAssistant;




import React, { useState } from 'react';
import axios from 'axios';
import './ChatAssistant.css'; // Ensure the CSS file is imported for styling

const ChatAssistant = () => {
  const [userInput, setUserInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => setUserInput(e.target.value);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const userMessage = { role: 'user', content: userInput };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setError(null);

    try {
      const response = await axios.post('http://localhost:5001/api/chat', { message: userInput });
      const assistantMessage = { role: 'assistant', content: response.data.reply };
      setMessages((prevMessages) => [...prevMessages, assistantMessage]);
    } catch (err) {
      setError('Error connecting to the chat server. Please try again.');
      console.error('Error:', err);
    }

    setUserInput('');
  };

  return (
    <div className="chat-assistant">
      <div className="chat-window">
        {messages.map((msg, index) => (
          <div key={index} className={`message ${msg.role}`}>
            <div className="message-content">{msg.content}</div>
          </div>
        ))}
      </div>
      {error && <p className="error-message">{error}</p>}
      <div className="input-area">
        <input
          type="text"
          value={userInput}
          onChange={handleInputChange}
          placeholder="Ask me anything..."
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
};

export default ChatAssistant;
