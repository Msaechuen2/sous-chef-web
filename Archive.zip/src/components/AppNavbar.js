import React from 'react';
import { Navbar, NavbarBrand, NavbarContent, NavbarItem, Link } from "@nextui-org/react";

export default function AppNavbar() {
  return (
    <Navbar isBordered variant="sticky" className="bg-white shadow-md">
      <NavbarBrand>
        <Link href="/" color="text" css={{ fontWeight: 'bold', fontSize: '1.5rem' }}>My NextUI App</Link>
      </NavbarBrand>
      <NavbarContent hideIn="xs">
        <NavbarItem>
          <Link href="/" color="text">Home</Link>
        </NavbarItem>
        <NavbarItem>
          <Link href="/about" color="text">About</Link>
        </NavbarItem>
        <NavbarItem>
          <Link href="/contact" color="text">Contact</Link>
        </NavbarItem>
      </NavbarContent>
    </Navbar>
  );
}
