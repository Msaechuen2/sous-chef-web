// import React from 'react';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
// import 'swiper/css/autoplay';
// import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// import './HomePage.css';

// const popularRecipes = [
//   { id: 1, name: 'Spaghetti Carbonara', imageUrl: './src/images/home1.jpg' },
//   { id: 2, name: 'Chicken Parmesan', imageUrl: '/home1.jpg' },
//   { id: 3, name: 'Beef Tacos', imageUrl: 'home1.jpg' },
//   { id: 4, name: 'Vegetable Stir Fry', imageUrl: 'home1.jpg' },
// ];

// const HomePage = () => {
//   return (
//     <div className="homepage">
//       {/* Hero Section */}
//       <section className="hero">
//         <h1>Welcome to Sous Chef</h1>
//         <p>Your personal cooking companion, here to help with recipes, meal planning, and more!</p>
//         <button className="cta-button">Explore Recipes</button>
//       </section>

//       {/* Features Section */}
//       <section className="features">
//         <h2>Our Features</h2>
//         <div className="feature-cards">
//           <div className="feature-card">
//             <h3>Recipe Search</h3>
//             <p>Discover a world of recipes at your fingertips.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Meal Planner</h3>
//             <p>Plan your meals for the week with ease.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Nutrition Management</h3>
//             <p>Stay on top of your nutritional goals.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Chat Assistant</h3>
//             <p>Get instant cooking advice anytime.</p>
//           </div>
//         </div>
//       </section>

//       {/* Popular Recipes */}
//       <section className="popular-recipes">
//         <h2>Popular Recipes</h2>
//         <Swiper
//           modules={[Navigation, Pagination, Autoplay]}
//           loop={true} // Enable looping
//           autoplay={{ delay: 3000, disableOnInteraction: false }} // Autoplay settings
//           spaceBetween={20}
//           slidesPerView={3}
//           navigation
//           pagination={{ clickable: true }}
//         >
//           {popularRecipes.map((recipe) => (
//             <SwiperSlide key={recipe.id}>
//               <div className="recipe-card">
//                 <img src={recipe.imageUrl} alt={recipe.name} className="recipe-image" />
//                 <h3>{recipe.name}</h3>
//               </div>
//             </SwiperSlide>
//           ))}
//         </Swiper>
//       </section>


//       {/* Cooking Tips */}
//       <section className="cooking-tips">
//         <h2>Cooking Tips & Articles</h2>
//         <div className="tips-cards">
//           <div className="tip-card">
//             <h3>Tip Title</h3>
//             <p>Brief tip description here.</p>
//           </div>
//           {/* Add more tip cards as needed */}
//         </div>
//       </section>

//       {/* Call to Action */}
//       <section className="cta-section">
//         <h2>Ready to start cooking?</h2>
//         <button className="cta-button">Join Sous Chef Today</button>
//       </section>
//     </div>
//   );
// };

// export default HomePage;


// import React, { useEffect, useState } from 'react';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
// import 'swiper/css/autoplay';
// import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// import './HomePage.css';

// const HomePage = () => {
//   // State to hold popular recipes data fetched from the backend
//   const [popularRecipes, setPopularRecipes] = useState([]);

//   // Fetch popular recipes from the backend API
//   useEffect(() => {
//     const fetchPopularRecipes = async () => {
//       try {
//         const response = await fetch('/api/recipes/popular'); // Replace with your actual API endpoint
//         const data = await response.json();
//         setPopularRecipes(data); // Update state with fetched recipes
//       } catch (error) {
//         console.error('Error fetching popular recipes:', error);
//       }
//     };

//     fetchPopularRecipes();
//   }, []);

//   return (
//     <div className="homepage">
//       {/* Hero Section */}
//       <section className="hero">
//         <h1>Welcome to Sous Chef</h1>
//         <p>Your personal cooking companion, here to help with recipes, meal planning, and more!</p>
//         <button className="cta-button">Explore Recipes</button>
//       </section>

//       {/* Features Section */}
//       <section className="features">
//         <h2>Our Features</h2>
//         <div className="feature-cards">
//           <div className="feature-card">
//             <h3>Recipe Search</h3>
//             <p>Discover a world of recipes at your fingertips.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Meal Planner</h3>
//             <p>Plan your meals for the week with ease.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Nutrition Management</h3>
//             <p>Stay on top of your nutritional goals.</p>
//           </div>
//           <div className="feature-card">
//             <h3>Chat Assistant</h3>
//             <p>Get instant cooking advice anytime.</p>
//           </div>
//         </div>
//       </section>

//       {/* Popular Recipes */}
//       <section className="popular-recipes">
//         <h2>Popular Recipes</h2>
//         <Swiper
//           modules={[Navigation, Pagination, Autoplay]}
//           loop={true} // Enable looping
//           autoplay={{ delay: 3000, disableOnInteraction: false }} // Autoplay settings
//           spaceBetween={20}
//           slidesPerView={3}
//           navigation
//           pagination={{ clickable: true }}
//         >
//           {popularRecipes.map((recipe) => (
//             <SwiperSlide key={recipe.id}>
//               <div className="recipe-card">
//                 <img src={recipe.imageUrl} alt={recipe.name} className="recipe-image" />
//                 <h3>{recipe.name}</h3>
//               </div>
//             </SwiperSlide>
//           ))}
//         </Swiper>
//       </section>

//       {/* Cooking Tips */}
//       <section className="cooking-tips">
//         <h2>Cooking Tips & Articles</h2>
//         <div className="tips-cards">
//           <div className="tip-card">
//             <h3>Tip Title</h3>
//             <p>Brief tip description here.</p>
//           </div>
//           {/* Add more tip cards as needed */}
//         </div>
//       </section>

//       {/* Call to Action */}
//       <section className="cta-section">
//         <h2>Ready to start cooking?</h2>
//         <button className="cta-button">Join Sous Chef Today</button>
//       </section>
//     </div>
//   );
// };

// import React from 'react';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
// import 'swiper/css/autoplay';
// import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// import RecipeReviewCard from '../components/RecipeReviewCard'; // Ensure this path matches your structure
// import './HomePage.css';

// const sampleRecipes = [
//   {
//     id: 1,
//     name: 'Spaghetti Carbonara',
//     description: 'A classic Italian pasta dish with eggs, cheese, pancetta, and pepper.',
//     imageUrl: './src/images/spaghetti.jpg',
//   },
//   {
//     id: 2,
//     name: 'Chicken Parmesan',
//     description: 'Crispy chicken breasts topped with marinara sauce and melted cheese.',
//     imageUrl: './src/images/chicken_parmesan.jpg',
//   },
//   {
//     id: 3,
//     name: 'Beef Tacos',
//     description: 'Soft tacos filled with seasoned beef, fresh salsa, and guacamole.',
//     imageUrl: './src/images/beef_tacos.jpg',
//   },
//   {
//     id: 4,
//     name: 'Vegetable Stir Fry',
//     description: 'A quick and easy stir fry with colorful veggies and savory sauce.',
//     imageUrl: './src/images/vegetable_stir_fry.jpg',
//   },
// ];

// const HomePage = () => {
//   return (
//     <div className="homepage">
//       {/* Hero Section */}
//       <section className="hero">
//         <h1>Welcome to Sous Chef</h1>
//         <p>Your personal cooking companion, here to help with recipes, meal planning, and more!</p>
//         <button className="cta-button">Explore Recipes</button>
//       </section>

//       {/* Popular Recipes Section */}
//       <section className="popular-recipes">
//         <h2>Popular Recipes</h2>
//         <Swiper
//           modules={[Navigation, Pagination, Autoplay]}
//           loop={true} // Enable looping
//           autoplay={{ delay: 3000, disableOnInteraction: false }} // Autoplay settings
//           spaceBetween={20}
//           slidesPerView={3}
//           navigation
//           pagination={{ clickable: true }}
//         >
//           {sampleRecipes.map((recipe) => (
//             <SwiperSlide key={recipe.id}>
//               <RecipeReviewCard
//                 title={recipe.name}
//                 description={recipe.description}
//                 imageUrl={recipe.imageUrl}
//               />
//             </SwiperSlide>
//           ))}
//         </Swiper>
//       </section>
//     </div>
//   );
// };

// export default HomePage;


import React, { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/autoplay';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import RecipeReviewCard from '../components/RecipeReviewCard'; // Ensure this path is correct
import './HomePage.css';

const HomePage = () => {
  // State to hold popular recipes data fetched from the backend
  const [popularRecipes, setPopularRecipes] = useState([]);

  // Fetch popular recipes from the backend API
  useEffect(() => {
    const fetchPopularRecipes = async () => {
      try {
        const response = await fetch('/api/recipes/popular'); // Your backend API endpoint
        const data = await response.json();
        setPopularRecipes(data); // Update state with fetched recipes
      } catch (error) {
        console.error('Error fetching popular recipes:', error);
      }
    };

    fetchPopularRecipes();
  }, []);

  return (
    <div className="homepage">
      {/* Hero Section */}
      <section className="hero">
        <h1>Welcome to Sous Chef</h1>
        <p>Your personal cooking companion, here to help with recipes, meal planning, and more!</p>
        <button className="cta-button">Explore Recipes</button>
      </section>

      {/* Popular Recipes Section */}
      <section className="popular-recipes">
        <h2>Popular Recipes</h2>
        <Swiper
          modules={[Navigation, Pagination, Autoplay]}
          loop={true}
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          spaceBetween={20}
          slidesPerView={3}
          navigation
          pagination={{ clickable: true }}
        >
          {popularRecipes.map((recipe) => (
            <SwiperSlide key={recipe._id}>
              <RecipeReviewCard
                title={recipe.name}
                description={recipe.description}
                imageUrl={recipe.imageUrl}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </section>
    </div>
  );
};

export default HomePage;
