import React from 'react';

const MealPlanner = () => {
  return <h1>Meal Planner</h1>;
};

export default MealPlanner;
