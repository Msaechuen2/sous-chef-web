import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const RecipePage = () => {
  const {recipeId} = useParams();
  console.log(recipeId)
  const [recipe, setRecipe] = useState(null);

  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        const response = await fetch(`http://localhost:5001/recipes/${recipeId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch recipe');
        }
        const data = await response.json();
        setRecipe(data);
      } catch (error) {
        console.error('Error fetching recipe:', error);
      }
    };

    fetchRecipe();
  }, [recipeId]);

  if (!recipe) {
    return <p>Loading recipe...</p>;
  }

  return (
    <div style={{ display: 'flex', padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      {/* Left side: Recipe Image */}
      <div style={{ flex: '1', marginRight: '20px' }}>
        <img src={recipe.imageUrl} alt={recipe.name} style={{ width: '100%', borderRadius: '8px' }} />
      </div>

      {/* Right side: Recipe Details */}
      <div style={{ flex: '2' }}>
        <h1>{recipe.name}</h1>
        <p><strong>Ingredients:</strong></p>
        <ul>
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))}
        </ul>
      </div>

      {/* Below: Instructions */}
      <div style={{ marginTop: '20px' }}>
        <h2>Instructions</h2>
        <ol>
          {recipe.instructions.map((step, index) => (
            <li key={index}>{step}</li>
          ))}
        </ol>
      </div>
    </div>
  );
};

export default RecipePage;
