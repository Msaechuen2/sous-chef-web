// pages/recipes/[recipe].js

import React from 'react';
import Image from 'next/image';

// Example function to fetch recipe data
export async function getServerSideProps(context) {
  const { recipe } = context.params;
  
  // Fetch recipe data from your backend API or a local JSON file
  const res = await fetch(`http://your-api-url/recipes/${recipe}`);
  const data = await res.json();

  return { props: { recipeData: data } };
}

const RecipePage = ({ recipeData }) => {
  const { name, imageUrl, ingredients, instructions } = recipeData;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', padding: '20px' }}>
      {/* Title */}
      <h1>{name}</h1>
      
      {/* Recipe Details */}
      <div style={{ display: 'flex', gap: '20px', alignItems: 'start' }}>
        {/* Image on the left */}
        <div>
          <Image src={imageUrl} alt={name} width={300} height={300} layout="responsive" />
        </div>

        {/* Ingredients on the right */}
        <div>
          <h2>Ingredients</h2>
          <ul>
            {ingredients.map((ingredient, index) => (
              <li key={index}>{ingredient}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Instructions below */}
      <div>
        <h2>Instructions</h2>
        <ol>
          {instructions.map((step, index) => (
            <li key={index}>{step}</li>
          ))}
        </ol>
      </div>
    </div>
  );
};

export default RecipePage;
