import { Navbar, NavbarBrand, NavbarContent, NavbarItem, Link, Button, Input, Dropdown, DropdownItem, DropdownTrigger, DropdownMenu, Avatar, NextUIProvider } from "@nextui-org/react";
import { ChefHatLogo } from "./components/ChefHatLogo.js";
import { SearchIcon } from "./components/SearchIcon.js";
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/Home';
import MealPlanner from './pages/MealPlanner';
import ChatbotPopup from './components/ChatbotPopup';
import RecipePage from './pages/RecipePage'; 

function AppNavbar() {
  return (
    <Navbar>
      {/* Centered NavbarBrand with logo and name */}
      <NavbarBrand>
        <ChefHatLogo />
        <p className="font-bold text-inherit">Sous Chef</p>
      </NavbarBrand>
      
      {/* Center NavbarContent with navigation links */}
      <NavbarContent className="hidden sm:flex gap-4" justify="center">
        <NavbarItem>
          <Link color="foreground" href="#">
            Features
          </Link>
        </NavbarItem>
        <NavbarItem isActive>
          <Link href="#" aria-current="page">
            Customers
          </Link>
        </NavbarItem>
        <NavbarItem>
          <Link color="foreground" href="#">
            Integrations
          </Link>
        </NavbarItem>
      </NavbarContent>

      {/* Right NavbarContent with search, login, signup, and profile dropdown */}
      <NavbarContent justify="end">
        {/* Search Bar */}
        <NavbarItem>
          <Input
            classNames={{
              base: "max-w-full sm:max-w-[10rem] h-10",
              mainWrapper: "h-full",
              input: "text-small",
              inputWrapper: "h-full font-normal text-default-500 bg-default-400/20 dark:bg-default-500/20",
            }}
            placeholder="Type to search..."
            size="sm"
            startContent={<SearchIcon size={18} />}
            type="search"
          />
        </NavbarItem>

        {/* Login Link */}
        <NavbarItem className="hidden lg:flex">
          <Link href="#">Login</Link>
        </NavbarItem>

        {/* Sign Up Button */}
        <NavbarItem>
          <Button as={Link} color="primary" href="#" variant="flat">
            Sign Up
          </Button>
        </NavbarItem>

        
      </NavbarContent>
    </Navbar>
  );
}

export default function App() {
  return (
    <NextUIProvider>
      <Router>
        <AppNavbar /> {/* Navbar displayed on all pages */}
        <div>
          <Routes>
            <Route path="/home" element={<HomePage />} />
            <Route path="/meal-planner" element={<MealPlanner />} />
            <Route path="/recipes/:recipeId" element={<RecipePage />} />
          </Routes>
          <ChatbotPopup />
        </div>
      </Router>
    </NextUIProvider>
  );
}
