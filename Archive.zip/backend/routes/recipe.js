const express = require('express');
const router = express.Router();
const Recipe = require('../models/Recipes'); // assuming you have a Recipe model

router.get('/popular', async (req, res) => {
  try {
    const recipes = await Recipe.find().limit(10); // limit the number of popular recipes
    res.json(recipes);
  } catch (error) {
    console.error('Error fetching popular recipes:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
