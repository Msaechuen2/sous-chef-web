const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const PORT = 5001;
const mongoose = require('mongoose');
const Recipe = require('./models/Recipes');
const recipeRoutes = require('./routes/recipe');
const mongoURI = 'mongodb+srv://user1:password_1234@sous-chef.zx7v4.mongodb.net/?retryWrites=true&w=majority&appName=sous-chef';

app.use(cors());
app.use(express.json());
app.use('/api/recipes', recipeRoutes);


mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

app.post('/add-recipe', async (req, res) => {
  try {
    const recipeData = req.body;
    const recipe = new Recipe(recipeData);
    await recipe.save();
    res.status(201).send(recipe);
  } catch (error) {
    res.status(400).send({ error: 'Error adding recipe' });
  }
});


app.get('/recipes', async (req, res) => {
  try {
    const recipes = await Recipe.find();
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching recipes' });
  }
});

app.get('/recipes/:id', async (req, res) => {
  try {
    console.log(req.params.id)
    const recipe = await Recipe.findById(req.params.id);
    console.log(recipe)
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    res.json(recipe);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;

  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-3.5-turbo-0125',
      messages: [
        { role: 'user', content: userMessage }
      ],
      max_tokens: 50,
    }, {
      headers: {
        'Authorization': `Bearer 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`
      }
    });

    const reply = response.data.choices[0].message.content.trim();
    res.json({ reply });
  } catch (error) {
    console.error('Error:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: 'Error connecting to ChatGPT' });
  }
});


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});



