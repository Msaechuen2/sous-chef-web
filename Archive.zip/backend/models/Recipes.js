const mongoose = require('mongoose');

const recipeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  ingredients: [{ type: String, required: true }],
  instructions: [{ type: String, required: true }],
  imageUrl: { type: String, required: true }
  // prepTime: { type: Number }, // Optional: in minutes
  // cookTime: { type: Number }, // Optional: in minutes
  // servings: { type: Number }   // Optional: number of servings
});

const Recipe = mongoose.model('recipes', recipeSchema);
module.exports = Recipe;